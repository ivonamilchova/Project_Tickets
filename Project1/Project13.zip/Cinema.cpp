#include "Cinema.h"
#include <iostream>
void Cinema::setAudits()
{
	size_t size;
	std::cout << "Input number of the auditoriums: ";
	std::cin >> size;

	
	for (size_t i = 0; i < size; i++)
	{
		Vector<size_t> tmp;
		size_t numberOfAudit;
		std::cout << "Input number of the auditorium:";
		std::cin >> numberOfAudit;

		size_t sizeRows;
		std::cout << "Input number of rows in the auditorium: ";
		std::cin >> sizeRows;

		for (size_t i = 0; i < sizeRows; i++)
		{
			size_t tmpSeats;
			std::cout << "Input number of seats of row" << i;
			std::cin >> tmpSeats;
			tmp.pushBack(tmpSeats);
		}
		Auditorium a(tmp, numberOfAudit);
		this->audits.pushBack(a);
	}
}

void Cinema::setEvents()
{
	size_t size;
	std::cout << "Input number of the events: ";
	std::cin >> size;

	for (size_t i = 0; i < size; i++)
	{
		Date d;
		d.init();

		String eventName;
		std::cout << "Input the name of event: ";
		std::cin >> eventName;

		size_t auditNumber;
		std::cout << "Input the number of the auditorium of the event: ";
		std::cin >> auditNumber;

		for (size_t i = 0; i < audits.getSize(); i++)
		{
			if (auditNumber == audits[i].getNumber()) {
				Event e(d, eventName, auditNumber, audits[i]);
				this->events.pushBack(e);
				break;
			}
		}
	}
	
}

Cinema::Cinema()
{
	this->setAudits();
}

void Cinema::addEvent()
{
	Date d;
	d.init();

	String eventName;
	std::cout << "Input the name of event: ";
	std::cin >> eventName;

	size_t auditNumber;
	std::cout << "Input the number of the auditorium of the event: ";
	std::cin >> auditNumber;

	for (size_t i = 0; i < audits.getSize(); i++)
	{
		if (auditNumber == audits[i].getNumber()) {
			Event e(d, eventName, auditNumber, audits[i]);
			this->events.pushBack(e);
			break;
		}
	}
}

void Cinema::buyTicket()
{
	std::cout << "Input the name of event: ";
	String eventName;
	std::cin >> eventName;

	size_t rowNumber;
	std::cout << "Input row: ";
	std::cin >> rowNumber;

	size_t seatNumber;
	std::cout << "Input seat: ";
	std::cin >> seatNumber;

	size_t eventSize = events.getSize();
	for (size_t i = 0; i < eventSize; i++)
	{
		if (eventName == events[i].getName()) {
			Ticket t = events[i].getTicket(rowNumber, seatNumber);
			if (t.isFree()) {
				t.buyFreeTicket();
			}
			else if (t.isReserved()){
				std::cout << "Enter the password: ";
				String password;
				std::cin >> password;

				std::cout << "Enter the notes: ";
				String notes;
				std::cin >> notes;

				t.buy(password, notes);
			}
			break;
		}
	}


	/*
	�� �������� ������ �� �� �������
	String password;
	String notes;
	State state;*/
}
