#include "Event.h"

Event::Event()
{
	this->auditoriumNumber = 0;
}

Event::Event(const Date& dateParam, const String& eventNameParam, const size_t& auditoriumNumberParam, const Auditorium& audit)
{
	this->date = dateParam;
	this->eventName = eventNameParam;
	this->auditoriumNumber = auditoriumNumberParam;
	
	for (size_t i = 0; i < audit.getSize(); i++)
	{
		Vector<Ticket> ts;
		for (size_t j = 0; j < audit.getSeatsAt(i); j++)
		{
			Ticket t(i, j, FREE);
			ts.pushBack(t);
		}
		tickets.pushBack(ts);
	}

}

String Event::getName() const
{
	return this->eventName;
}

Ticket& Event::getTicket(const size_t rowNumber, const size_t seat) const
{
	return tickets.getAt(rowNumber).getAt(seat);
}


