#ifndef __CINEMA
#define __CINEMA
#include "Vector.h"
#include "Event.h"
#include "Auditorium.h"


class Cinema {
private:
	Vector<Event> events;
	Vector<Auditorium> audits;

public:
	void setAudits();
	void setEvents();
	Cinema();
	void addEvent();
	void buyTicket();


};
#endif // !__CINEMA
